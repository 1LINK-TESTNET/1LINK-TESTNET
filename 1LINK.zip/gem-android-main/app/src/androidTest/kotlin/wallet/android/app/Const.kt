package wallet.android.app

val testPhrase = "seminar cruel gown pause law tortoise step stairs size amused pond weapon"