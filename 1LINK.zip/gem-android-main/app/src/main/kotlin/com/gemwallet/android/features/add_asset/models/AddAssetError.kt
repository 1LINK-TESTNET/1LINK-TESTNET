package com.gemwallet.android.features.add_asset.models

enum class AddAssetError {
    None,
    InvalidAddress,
    TokenNotFound,
}