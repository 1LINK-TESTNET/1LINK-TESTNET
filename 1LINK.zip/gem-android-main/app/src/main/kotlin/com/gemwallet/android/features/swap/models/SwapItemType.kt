package com.gemwallet.android.features.swap.models

enum class SwapItemType {
    Pay,
    Receive,
}