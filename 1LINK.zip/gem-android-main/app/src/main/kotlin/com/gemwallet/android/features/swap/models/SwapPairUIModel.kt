package com.gemwallet.android.features.swap.models

class SwapPairUIModel(
    val from: SwapItemModel,
    val to: SwapItemModel,
)