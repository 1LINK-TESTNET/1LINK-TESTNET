package com.gemwallet.android.features.swap.models

enum class PriceImpactType {
    Low,
    Medium,
    High,
    Positive,
}