package com.gemwallet.android.features.settings.networks.models

enum class AddSourceType {
    None,
    Network,
    Explorer,
}