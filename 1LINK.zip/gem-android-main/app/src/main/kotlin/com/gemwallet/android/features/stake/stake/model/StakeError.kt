package com.gemwallet.android.features.stake.stake.model

enum class StakeError {
    None,
}