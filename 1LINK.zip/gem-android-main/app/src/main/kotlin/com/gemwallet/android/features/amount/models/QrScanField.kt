package com.gemwallet.android.features.amount.models

enum class QrScanField {
    None,
    Address,
    Memo,
}