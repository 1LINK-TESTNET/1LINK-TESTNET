package com.gemwallet.android.features.onboarding

object OnboardingDest {
    const val route: String = "onboarding"
}