package com.gemwallet.android.features.swap.models

data class SwapRate(
    val forward: String,
    val reverse: String,
)
