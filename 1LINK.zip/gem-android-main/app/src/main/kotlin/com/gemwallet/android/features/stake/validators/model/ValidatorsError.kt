package com.gemwallet.android.features.stake.validators.model

enum class ValidatorsError {
    None,
    NotFound,
}