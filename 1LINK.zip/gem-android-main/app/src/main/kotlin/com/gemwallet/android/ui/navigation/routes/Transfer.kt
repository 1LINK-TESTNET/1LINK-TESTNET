package com.gemwallet.android.ui.navigation.routes

import kotlinx.serialization.Serializable

@Serializable
object Transfer