package com.gemwallet.android.ui.components

import android.content.Context

class ReviewManager(val context: Context) {
    fun open() { }
}