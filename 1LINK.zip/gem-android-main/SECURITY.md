# Security Policy

See https://github.com/gemwalletcom/gem-ios/blob/main/SECURITY.md
