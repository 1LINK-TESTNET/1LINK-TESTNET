package com.gemwallet.android.blockchain.clients.solana.models

class SolanaTokenOwner(val owner: String)