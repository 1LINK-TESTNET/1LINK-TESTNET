package com.gemwallet.android.blockchain.clients.polkadot.services

interface PolkadotServices : PolkadotBalancesService,
        PolkadotBroadcastService,
        PolkadotFeeService,
        PolkadotNodeStatusService,
        PolkadotTransactionService