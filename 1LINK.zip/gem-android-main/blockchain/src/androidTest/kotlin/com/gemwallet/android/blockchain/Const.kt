package com.gemwallet.android.blockchain

val testPhrase = "seminar cruel gown pause law tortoise step stairs size amused pond weapon"