package com.gemwallet.android.blockchain

fun includeLibs() {
    System.loadLibrary("TrustWalletCore")
    System.loadLibrary("gemstone")
}